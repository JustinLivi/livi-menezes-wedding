export const SIGINT = 'SIGINT';
export const SIGTERM = 'SIGTERM';
export const UNCAUGHT_EXCEPTION = 'uncaughtException';
